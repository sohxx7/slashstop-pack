#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <film:lens.glsl>
#endif
#include <minecraft:globals.glsl>

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
layout(location = 4) flat out int filmUi;
layout(location = 5) out vec2 glyphCorner;
const vec2 GLYPH_CORNERS[4] = vec2[4](vec2(0.0, 0.0), vec2(0.0, 1.0), vec2(1.0, 1.0), vec2(1.0, 0.0));
#ifdef IS_GUI
float filmBaseline(float poseScale, float y, float guiH) {
    return 0.0;
}
// (x, y, 글자 높이) 640x360 기준
const vec3 FILM_ANCHORS[15] = vec3[15](
    vec3(320.0, 334.0, 13.0),   // 대사
    vec3(320.0, 318.0, 13.0),   // 대사 윗줄
    vec3(320.0, 170.0, 34.0),   // 가운데 큰 글자
    vec3(320.0, 208.0, 13.0),   // 가운데 작은 글자
    vec3(560.0, 22.0, 13.0),    // 카운트다운
    vec3(120.0, 22.0, 9.0),     // 장소
    vec3(320.0, 226.0, 14.0),   // 투표 줄
    vec3(320.0, 248.0, 14.0),
    vec3(320.0, 270.0, 14.0),
    vec3(320.0, 22.0, 11.0),    // 위 막대 가운데
    vec3(190.0, 236.0, 30.0),   // 프리즈 이름
    vec3(190.0, 270.0, 12.0),   // 프리즈 소개
    vec3(320.0, 293.0, 17.0),   // 사진 아래 여백의 손글씨 (final.fsh 인화지와 맞춘다)
    vec3(452.0, 262.0, 10.0),   // 사진 오른쪽 아래 날짜 도장
    vec3(320.0, 38.0, 8.0)      // 위 막대 아래쪽: 드래곤 체력(둘째 보스바를 빌려 쓴다)
);
const float FILM_SIZES[8] = float[8](1.0, 0.75, 0.6, 1.3, 1.6, 2.2, 3.2, 4.5);
const vec3 FILM_PALETTE[16] = vec3[16](
    vec3(0.961, 0.937, 0.871), vec3(0.902, 0.753, 0.408), vec3(0.710, 0.118, 0.118), vec3(0.640, 0.640, 0.620),
    vec3(1.0, 1.0, 1.0), vec3(0.0, 0.0, 0.0), vec3(0.961, 0.455, 0.247), vec3(0.525, 0.900, 0.900),
    vec3(1.0, 1.0, 0.333), vec3(0.420, 0.410, 0.390), vec3(0.780, 0.600, 0.900), vec3(1.0, 0.25, 0.25),
    vec3(0.650, 0.800, 1.0), vec3(0.500, 0.880, 0.560), vec3(0.150, 0.140, 0.190), vec3(1.0, 0.560, 0.150));
#endif

void main() {
    filmUi = 0;
    glyphCorner = GLYPH_CORNERS[gl_VertexIndex % 4];
#ifdef IS_GUI
    {
        ivec3 ci = ivec3(Color.rgb * 255.0 + 0.5);
        if (ci.r >= 192 && ci.g >= 192 && ci.b >= 192 && !(ci.r == 255 && ci.g == 255 && ci.b == 255)) {
            int d = ((ci.r & 63) << 12) | ((ci.g & 63) << 6) | (ci.b & 63);
            int anchor = (d >> 13) & 31;
            int pal = (d >> 9) & 15;
            int al = (d >> 5) & 15;
            int size = (d >> 2) & 7;
            int fx = d & 3;
            float guiW = 2.0 / abs(ProjMat[0][0]);
            float guiH = 2.0 / abs(ProjMat[1][1]);
            vec4 mv = ModelViewMat * vec4(Position, 1.0);
            vec2 c = vec2(floor(guiW * 0.5), floor(guiH * 0.5));
            vec2 local;
            if (fx == 0) {
                local = mv.xy - vec2(c.x, floor(guiH) - 68.0 - 4.0);      // 액션바
            } else if (fx == 1) {
                local = (mv.xy - c) / 4.0 + vec2(0.0, 10.0);              // 타이틀
            } else if (fx == 2) {
                local = (mv.xy - c) / 2.0 - vec2(0.0, 5.0);               // 서브타이틀
            } else {
                int slot = anchor == 14 ? 1 : clamp(anchor - 4, 0, 4);
                local = mv.xy - vec2(c.x, 3.0 + 19.0 * float(slot));   // 보스바
            }
            vec3 an = FILM_ANCHORS[min(anchor, 14)];
            float unit = an.z * FILM_SIZES[size] / 16.0;
            vec2 design = vec2(an.x, an.y) + vec2(local.x, local.y - 8.0) * unit;
            float u = min(ScreenSize.x / 640.0, ScreenSize.y / 360.0);
            vec2 screen = vec2((ScreenSize.x - 640.0 * u) * 0.5 + design.x * u, (ScreenSize.y - 360.0 * u) * 0.5 + design.y * u);
            vec2 gui = screen * vec2(guiW / ScreenSize.x, guiH / ScreenSize.y);
            gl_Position = ProjMat * vec4(gui, mv.z, 1.0);
            vertexColor = vec4(FILM_PALETTE[pal], float(al) / 15.0 * Color.a);
            texCoord0 = UV0;
            filmUi = 1;
            return;
        }
    }
#endif
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    gl_Position.xy *= film_lens_scale(ProjMat);
    if (ProjMat[3][3] == 0.0 && floor(GameTime * 24000.0 * 0.25 + 0.01) >= 5950.0) {
        gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
    }
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
