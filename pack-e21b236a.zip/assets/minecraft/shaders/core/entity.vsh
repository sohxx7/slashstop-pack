#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>

#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#include <minecraft:light.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <film:lens.glsl>
#include <film:world.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
layout(location = 5) in vec3 Normal;

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler1;
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler2;
#endif

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;

#ifdef PER_FACE_LIGHTING
layout(location = 2) out vec4 vertexPerFaceColorBack;
layout(location = 3) out vec4 vertexPerFaceColorFront;
#else
layout(location = 2) out vec4 vertexColor;
#endif

#ifndef EMISSIVE
layout(location = 4) out vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
layout(location = 5) out vec4 overlayColor;
#endif

layout(location = 6) out vec2 texCoord0;
#ifdef GLINT
layout(location = 7) out vec2 texCoordGlint;
#endif

layout(location = 8) out float filmBlock;
layout(location = 9) flat out int filmGui;
layout(location = 10) flat out float filmEmissive;
layout(location = 11) flat out float filmHand;

void main() {
    filmHand = (ProjMat[3][3] == 0.0 && length(Position) < 2.6 && FogEnvironmentalStart * 750.0 < 400.0) ? 1.0 : 0.0;
    vec3 filmRel = film_deform(Position, Position + vec3(CameraBlockPos) - CameraOffset);
    gl_Position = ProjMat * ModelViewMat * vec4(filmRel, 1.0);
    gl_Position.xy *= film_lens_scale(ProjMat);
    filmBlock = float(UV2.x) / 240.0;
    filmGui = ProjMat[3][3] != 0.0 ? 1 : 0;
    filmEmissive = 0.0;
    // 컷신에는 1인칭 손을 그리지 않는다(투표 때문에 잠깐 모험 모드가 된다)
    if (filmGui == 0 && ((FogEnvironmentalStart * 750.0 >= 400.0 && length(Position) < 1.2) || film_black())) {
        gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
    }

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

#ifdef PER_FACE_LIGHTING
    vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    vertexPerFaceColorBack = minecraft_mix_light_separate(-light, Color);
    vertexPerFaceColorFront = minecraft_mix_light_separate(light, Color);
#elif defined(NO_CARDINAL_LIGHTING)
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
    lightMapColor = sample_lightmap(Sampler2, UV2);
#endif

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

    texCoord0 = UV0;

#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

#ifdef GLINT
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif
}
