#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>

// /stop: 조명은 후처리에서 다시 계산한다.
// 라이트맵은 하늘빛 모양(실내/실외)만 남기고, 블록빛은 알파 G버퍼로 따로 보낸다.
// 알파 맨 윗줄 픽셀은 Sodium 지형 셰이더로 가는 데이터: 세계 변형 값, 카메라 블록 좌표.
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

float byteOf(float v, int idx) {
    int i = int(v);
    return float((idx == 0 ? (i >> 8) : i) & 255) / 255.0;
}

void main() {
    float sky = floor(texCoord.y * 16.0) / 15.0;
    float s = mix(0.42, 1.0, pow(sky, 1.3));
    ivec2 p = ivec2(gl_FragCoord.xy);
    float a = 1.0;
    if (p.y == 0 && p.x < 8) {
        float v = floor(GameTime * 24000.0 * 0.25 + 0.01);
        if (p.x < 2) {
            a = byteOf(v, p.x);
        } else if (p.x < 4) {
            a = byteOf(float(CameraBlockPos.y) + 32768.0, p.x - 2);
        } else if (p.x < 6) {
            a = byteOf(float(CameraBlockPos.x) + 32768.0, p.x - 4);
        } else {
            a = byteOf(float(CameraBlockPos.z) + 32768.0, p.x - 6);
        }
    }
    fragColor = vec4(vec3(s), a);
}
