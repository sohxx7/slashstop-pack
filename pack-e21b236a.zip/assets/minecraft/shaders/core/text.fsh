#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) flat in int filmUi;
layout(location = 5) in vec2 glyphCorner;

// 글꼴 시트는 NEAREST 라서 화면 글자는 직접 필터링한다. 칸 밖은 읽지 않는다(Vulkan 에서 빈 틈이 지워져 있지 않다).
vec4 filmTexel(vec2 uv, vec2 ts, vec2 lo, vec2 hi) {
    vec2 p = clamp(uv * ts - 0.5, lo, hi);
    vec2 g = fract(p);
    ivec2 i0 = ivec2(floor(p));
    ivec2 i1 = min(i0 + 1, ivec2(hi));
    vec4 a = texelFetch(Sampler0, i0, 0);
    vec4 b = texelFetch(Sampler0, ivec2(i1.x, i0.y), 0);
    vec4 c = texelFetch(Sampler0, ivec2(i0.x, i1.y), 0);
    vec4 d = texelFetch(Sampler0, i1, 0);
    a.rgb *= a.a; b.rgb *= b.a; c.rgb *= c.a; d.rgb *= d.a;
    return mix(mix(a, b, g.x), mix(c, d, g.x), g.y);
}

vec4 filmSample() {
    vec2 ts = vec2(textureSize(Sampler0, 0));
    vec2 dx = dFdx(texCoord0);
    vec2 dy = dFdy(texCoord0);
    mat2 toUv = mat2(dx, dy) * inverse(mat2(dFdx(glyphCorner), dFdy(glyphCorner)));
    vec2 c0 = texCoord0 - toUv * glyphCorner;
    vec2 c1 = c0 + toUv * vec2(1.0);
    vec2 lo = round(min(c0, c1) * ts);
    vec2 hi = max(round(max(c0, c1) * ts) - 1.0, lo);
    vec4 sum = vec4(0.0);
    for (int y = 0; y < 3; y++) {
        for (int x = 0; x < 3; x++) {
            vec2 o = (vec2(float(x), float(y)) - 1.0) * 0.33;
            sum += filmTexel(texCoord0 + dx * o.x + dy * o.y, ts, lo, hi);
        }
    }
    sum /= 9.0;
    if (sum.a > 0.0) {
        sum.rgb /= sum.a;
    }
    return sum;
}

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

void main() {
    if (filmUi == 1) {
        #ifdef IS_GRAYSCALE
        vec4 filmS = filmSample().rrrr;
        #else
        vec4 filmS = filmSample();
        #endif
        vec4 filmC = filmS * vertexColor;
        if (filmC.a < 0.012) {
            discard;
        }
        #ifdef OIT_ALPHA_ONLY
        executeAlphaOnlyPhase(gl_FragCoord.z, filmC.a);
        #else
        fragColor = calculateFinalColor(filmC);
        #endif
        return;
    }
    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;

    if (color.a < 0.1) {
        discard;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
