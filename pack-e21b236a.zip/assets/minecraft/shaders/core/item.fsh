#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif
layout(location = 2) in vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) in vec4 lightMapColor;
layout(location = 4) in vec4 overlayColor;
#endif
layout(location = 5) in vec2 texCoord0;
#ifdef GLINT
layout(location = 6) in vec2 texCoordGlint;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

#ifndef OIT_ALPHA_ONLY
vec4 calculateFinalColor(vec4 color) {
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);// Glint color modulator?
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}
#endif

layout(location = 9) in float filmBlock;
layout(location = 10) flat in int filmGui;
layout(location = 11) flat in float filmEmissive;
layout(location = 12) flat in float filmHand;

void main() {
    if (filmHand > 0.5 && gl_FragCoord.y < (ScreenSize.y - ScreenSize.x / 2.39) * 0.5) {
        discard;
    }
    vec4 color = texture(Sampler0, texCoord0);
    vec3 filmKey = color.rgb;
    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    color *= vertexColor * ColorModulator;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #ifndef OIT_ACCUMULATE
    if (filmGui == 0 && fragColor.a >= 0.995) {
        fragColor.a = filmEmissive > 0.5 ? 0.3 : 1.0 - 0.5 * clamp(filmBlock, 0.0, 1.0);
    }
    #endif
    #ifndef OIT_ACCUMULATE
    if (filmGui == 0 && filmKey.r > 0.9 && filmKey.g < 0.1) {
        // 키 색: 자홍(B 1.0)=촛불, 진홍(B 0.5)=불씨. 항상 켜져 있다.
        fragColor = vec4(filmKey.b > 0.75 ? vec3(1.0, 0.8, 0.46) : vec3(1.0, 0.42, 0.12), 0.15);
    }
    if (filmGui == 0 && filmKey.r < 0.1 && filmKey.g > 0.9 && filmKey.b > 0.9) {
        // 하늘색 키: 백업실의 빛
        fragColor = vec4(0.3, 0.68, 0.8, 0.15);
    }
    #endif
    #endif
}
