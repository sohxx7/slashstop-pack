#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

// /stop: 아웃라인 타깃은 서버 -> 후처리 데이터 버퍼다. 글로우 디스플레이 하나가 작은 사각형 하나를 찍는다.
// 슬롯(R)   행 0: 0=카메라 / 행 1: 1..63 파라미터 / 행 2: 64..71 조명 위치 / 행 3: 80..87 조명 조준
layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;

layout(location = 0) out vec4 vertexColor;
layout(location = 1) out vec2 texCoord0;
layout(location = 2) flat out ivec2 kind;   // (종류, 사각형 x 시작)
layout(location = 3) flat out vec3 rel;
layout(location = 4) flat out vec3 view0;
layout(location = 5) flat out vec3 view1;
layout(location = 6) flat out vec3 view2;
layout(location = 7) flat out vec4 proj;

void main() {
    int slot = int(Color.r * 255.0 + 0.5);
    int x0 = 0;
    int y0 = 0;
    int w = 1;
    int k = 1;
    if (slot == 0) {
        x0 = 0; y0 = 0; w = 13; k = 0;
    } else if (slot < 64) {
        x0 = slot; y0 = 1; w = 1; k = 1;
    } else if (slot < 72) {
        x0 = (slot - 64) * 4; y0 = 2; w = 4; k = 2;
    } else if (slot < 80) {
        x0 = 64 + (slot - 72); y0 = 1; w = 1; k = 1;
    } else {
        x0 = (slot - 80) * 4; y0 = 3; w = 4; k = 2;
    }
    // 같은 버퍼에 앞서 그린 것에 따라 gl_VertexIndex의 시작값이 달라진다(4의 배수가 아닐 수 있다).
    // 네 모서리를 한 방향(반시계)으로 돌게만 하면 어느 값에서 시작해도 온전한 사각형이 된다.
    int v = gl_VertexIndex % 4;
    vec2 c = v == 0 ? vec2(0.0, 0.0) : (v == 1 ? vec2(1.0, 0.0) : (v == 2 ? vec2(1.0, 1.0) : vec2(0.0, 1.0)));
    vec2 px = vec2(float(x0) + c.x * float(w), float(y0) + c.y);
    gl_Position = vec4(px / ScreenSize * 2.0 - 1.0, 0.5, 1.0);

    vertexColor = Color;
    texCoord0 = UV0;
    kind = ivec2(k, x0);
    rel = Position;
    rel.y -= 384.0;     // 표식은 건축 높이 밖에 있다(Post.MARKER_UP)
    mat3 m = mat3(ModelViewMat);
    view0 = m[0];
    view1 = m[1];
    view2 = m[2];
    proj = vec4(ProjMat[0][0], ProjMat[1][1], ProjMat[2][2], ProjMat[3][2]);
}
