#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
layout(location = 2) in vec4 vertexPerFaceColorBack;
layout(location = 3) in vec4 vertexPerFaceColorFront;
#else
layout(location = 2) in vec4 vertexColor;
#endif

#ifndef EMISSIVE
layout(location = 4) in vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
layout(location = 5) in vec4 overlayColor;
#endif

layout(location = 6) in vec2 texCoord0;
#ifdef GLINT
layout(location = 7) in vec2 texCoordGlint;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    #endif

    #ifndef EMISSIVE
    color *= lightMapColor;
    #endif

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

layout(location = 8) in float filmBlock;
layout(location = 9) flat in int filmGui;
layout(location = 10) flat in float filmEmissive;
layout(location = 11) flat in float filmHand;

void main() {
    if (filmHand > 0.5 && gl_FragCoord.y < (ScreenSize.y - ScreenSize.x / 2.39) * 0.5) {
        discard;
    }
    vec4 color = texture(Sampler0, texCoord0);
    bool filmHolo = filmGui == 0 && abs(color.a - 0.5) < 0.06;
    vec3 filmSkin = color.rgb;

    #ifdef OIT_ADDITIVE
    color.a = min(0.99, color.a);
    #endif

    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    #ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
    #else
    vec4 faceVertexColor = vertexColor;
    #endif

    #ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord0).a) {
        discard;
    }
    // The dissolve effect entirely replaces translucency
    faceVertexColor.a = 1.0;
    #endif

    color *= faceVertexColor * ColorModulator;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT
    // 개선된 투명도 경로: 주사선은 모든 단계에서 지우고, 불투명으로 넘겨야 표식 색이 합성 뒤에도 그대로 남는다
    if (filmHolo) {
        if (mod(floor(gl_FragCoord.y / 2.0), 3.0) < 0.5) {
            discard;
        }
        color.a = 1.0;
    }
    #endif
    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #ifdef OIT_ACCUMULATE
    if (filmHolo) {
        float holoL = dot(filmSkin, vec3(0.3, 0.59, 0.11));
        float holoV = holoL * 0.8 + 0.2;
        fragColor = sampleColorForAccumulation(vec4(0.36 * holoV, 0.82 * holoV, 1.0, 1.0));
    }
    #endif
    #ifndef OIT_ACCUMULATE
    if (filmHolo) {
        // 소희: 스킨의 얼굴이 보이는 푸른 홀로그램. 주사선이 위로 흐른다.
        // 줄 사이로 뒤가 비쳐 보인다. R,G 에 밝기를 담고 B=1 은 후처리용 표식.
        if (mod(floor(gl_FragCoord.y / 2.0), 3.0) < 0.5) {
            discard;
        }
        float l = dot(filmSkin, vec3(0.3, 0.59, 0.11));
        float v = l * 0.8 + 0.2;
        fragColor = vec4(0.36 * v, 0.82 * v, 1.0, 1.0);
    } else if (filmGui == 0 && fragColor.a >= 0.995) {
        // 사람 모델은 블렌딩이 켜져 있다: 알파는 1로 두고 블록빛을 색으로 받는다
        float b = clamp(filmBlock, 0.0, 1.0);
        fragColor.rgb = min(fragColor.rgb * (1.0 + 1.5 * b), vec3(0.92));
        fragColor.a = 1.0;
    }
    #endif
    #endif
}
