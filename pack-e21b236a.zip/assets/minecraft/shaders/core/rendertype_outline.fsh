#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D Sampler0;

layout(location = 0) in vec4 vertexColor;
layout(location = 1) in vec2 texCoord0;
layout(location = 2) flat in ivec2 kind;
layout(location = 3) flat in vec3 rel;
layout(location = 4) flat in vec3 view0;
layout(location = 5) flat in vec3 view1;
layout(location = 6) flat in vec3 view2;
layout(location = 7) flat in vec4 proj;

layout(location = 0) out vec4 fragColor;

vec3 enc24(float v, float range) {
    float n = clamp(v / range * 0.5 + 0.5, 0.0, 1.0) * 16777215.0;
    int i = int(n + 0.5);
    return vec3(float((i >> 16) & 255), float((i >> 8) & 255), float(i & 255)) / 255.0;
}

void main() {
    if (texture(Sampler0, texCoord0).a == 0.0) {
        discard;
    }
    int x = int(gl_FragCoord.x) - kind.y;
    if (kind.x == 1) {
        fragColor = vec4(vertexColor.rgb, 1.0);
    } else if (kind.x == 0) {
        vec3 o;
        if (x < 3) {
            o = enc24(view0[x], 2.0);
        } else if (x < 6) {
            o = enc24(view1[x - 3], 2.0);
        } else if (x < 9) {
            o = enc24(view2[x - 6], 2.0);
        } else if (x == 9) {
            o = enc24(proj.x, 32.0);
        } else if (x == 10) {
            o = enc24(proj.y, 32.0);
        } else if (x == 11) {
            o = enc24(proj.z, 8.0);
        } else {
            o = enc24(proj.w, 8.0);
        }
        fragColor = vec4(o, 1.0);
    } else {
        // 조명: 카메라 기준 좌표 xyz + (G,B)
        if (x < 3) {
            fragColor = vec4(enc24(rel[x], 4096.0), 1.0);
        } else {
            fragColor = vec4(vertexColor.rgb, 1.0);
        }
    }
}
