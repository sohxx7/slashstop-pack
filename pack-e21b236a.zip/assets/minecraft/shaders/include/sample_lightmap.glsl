#ifndef MINECRAFT_SAMPLE_LIGHTMAP_GLSL
#define MINECRAFT_SAMPLE_LIGHTMAP_GLSL

// /stop: 라이트맵 알파에는 Sodium 지형용 데이터가 있다. 색만 쓴다.
vec4 sample_lightmap(sampler2D lightMap, ivec2 uv) {
    return vec4(texture(lightMap, clamp((uv / 256.0) + 0.5 / 16.0, vec2(0.5 / 16.0), vec2(15.5 / 16.0))).rgb, 1.0);
}

#endif
