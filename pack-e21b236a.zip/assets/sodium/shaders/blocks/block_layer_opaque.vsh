#version 330
#extension GL_ARB_separate_shader_objects : require

#include <sodium:globals.glsl>
#include <sodium:fog.glsl>
#include <sodium:chunk_vertex.glsl>

layout(location = 0) out vec4 v_Color;
layout(location = 1) out vec2 v_TexCoord;

#ifdef USE_FOG
layout(location = 2) out vec2 v_FragDistance;
layout(location = 3) out float fadeFactor;
#endif

uniform isamplerBuffer u_SectionTimeInfo;

#ifdef VULKAN
layout(push_constant) uniform PC {
    vec3 u_RegionOffset;
    int u_CurrentTime;
    uint u_RegionID;
};
#else
uniform vec3 u_RegionOffset;
uniform int u_CurrentTime;
uniform uint u_RegionID;
#endif

// 위치 4, 5번은 Sodium Extra 가 안개용으로 끼워 넣는다. 겹치면 셰이더가 컴파일되지 않아 게임이 꺼진다.
layout(location = 10) out float filmBlock;
layout(location = 11) out float filmEdge;

float film_lens_scale() {
    float t = u_EnvironmentFog.x * 750.0;
    if (t < 400.0) {
        return 1.0;
    }
    float fov = t / 200.0 * 3.14159265 / 180.0;
    return (1.0 / tan(fov * 0.5)) / abs(u_ProjectionMatrix[1][1]);
}

#ifndef OIT_ALPHA_ONLY
uniform sampler2D u_LightTex; // The light map texture sampler
#endif

uvec3 _get_relative_chunk_coord(uint pos) {
    // Packing scheme is defined by LocalSectionIndex
    return uvec3(pos) >> uvec3(5u, 0u, 2u) & uvec3(7u, 3u, 7u);
}

vec3 _get_draw_translation(uint pos) {
    return _get_relative_chunk_coord(pos) * vec3(16.0);
}

float film_hash1(float x) {
    return fract(sin(x * 91.3458) * 47453.5453);
}

// 세계 변형. 라이트맵 알파에 담긴 채널을 읽는다(lightmap.fsh).
vec3 film_deform_sodium(vec3 position, vec3 sectionOrigin) {
#ifndef OIT_ALPHA_ONLY
    float a0 = texelFetch(u_LightTex, ivec2(0, 0), 0).a * 255.0;
    float a1 = texelFetch(u_LightTex, ivec2(1, 0), 0).a * 255.0;
    float v = floor(a0 + 0.5) * 256.0 + floor(a1 + 0.5);
    if (v >= 5950.0) {
        return position + vec3(0.0, 100000.0, 0.0);
    }
    if (v < 64.0) {
        return position;
    }
    float cy = floor(texelFetch(u_LightTex, ivec2(2, 0), 0).a * 255.0 + 0.5) * 256.0 + floor(texelFetch(u_LightTex, ivec2(3, 0), 0).a * 255.0 + 0.5) - 32768.0;
    if (v >= 3100.0) {
        float fold = (v - 3100.0) / 2899.0;
        float R = mix(600.0, 42.0, fold);
        float h = position.y + cy - 64.0 + R;
        float an = position.z / R;
        return vec3(position.x, R - cos(an) * h - (cy - 64.0), sin(an) * h);
    }
    float cx = floor(texelFetch(u_LightTex, ivec2(4, 0), 0).a * 255.0 + 0.5) * 256.0 + floor(texelFetch(u_LightTex, ivec2(5, 0), 0).a * 255.0 + 0.5) - 32768.0;
    float cz = floor(texelFetch(u_LightTex, ivec2(6, 0), 0).a * 255.0 + 0.5) * 256.0 + floor(texelFetch(u_LightTex, ivec2(7, 0), 0).a * 255.0 + 0.5) - 32768.0;
    vec3 sw = floor((sectionOrigin + vec3(cx, cy, cz) + 8.0) / 16.0) * 16.0 + 8.0;
    float front = (v - 64.0) * 0.2;
    float id = dot(floor(sw / 16.0), vec3(1.0, 57.0, 113.0));
    float r = film_hash1(id);
    float over = max(abs(sw.x), abs(sw.z - 262.0)) - front + (r - 0.5) * 22.0;
    if (over <= 0.0) {
        return position;
    }
    vec3 local = position - (sectionOrigin + 8.0);
    float spin = over * (r - 0.5) * 0.012;
    float cs = cos(spin);
    float sn = sin(spin);
    local.xz = mat2(cs, sn, -sn, cs) * local.xz;
    local.xy = mat2(cs, -sn, sn, cs) * local.xy;
    vec3 c = sectionOrigin + 8.0;
    c.y += over * (0.55 + r * 0.9) + over * over * 0.002;
    c.xz += vec2(film_hash1(id + 3.1) - 0.5, film_hash1(id + 7.7) - 0.5) * over * 0.35;
    return c + local;
#else
    return position;
#endif
}

void main() {
    _vert_init();

    // Transform the chunk-local vertex position into world model space
    vec3 translation = u_RegionOffset + _get_draw_translation(_draw_id);
    vec3 position = _vert_position + translation;
    vec3 filmRelative = position;
    position = film_deform_sodium(position, translation);

#ifdef USE_FOG
    v_FragDistance = getFragDistance(position);

    int chunkId = int(_draw_id);
    int chunkFade = texelFetch(u_SectionTimeInfo, int((u_RegionID * 256u) + uint(chunkId))).r;
    int fadeTime = u_CurrentTime - chunkFade;
    float elapsed = float(fadeTime);
    float fade = clamp(float(u_CurrentTime - chunkFade) * u_FadePeriodInv, 0.0, 1.0);
    fadeFactor = (chunkFade < 0) ? 1.0 : fade;
#endif

    // Transform the vertex position into model-view-projection space
    gl_Position = u_ProjectionMatrix * u_ModelViewMatrix * vec4(position, 1.0);
    gl_Position.xy *= film_lens_scale();
    filmBlock = _vert_tex_light_coord.x * 256.0 / 240.0;
    filmEdge = (max(length(position.xz), abs(position.y)) - u_RenderFog.x * 0.82) / max(u_RenderFog.y - u_RenderFog.x * 0.82, 1.0);

    // Add the light color to the vertex color, and pass the texture coordinates to the fragment shader
#ifndef OIT_ALPHA_ONLY
    v_Color = vec4(_vert_color.rgb * texture(u_LightTex, _vert_tex_light_coord).rgb, _vert_color.a);
#else
    v_Color = _vert_color;
#endif

    v_TexCoord = (_vert_tex_diffuse_coord_bias * u_TexCoordShrink) + _vert_tex_diffuse_coord; // FMA for precision
}
