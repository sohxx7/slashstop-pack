#ifndef FILM_SKY
#define FILM_SKY

// 절차적 하늘. dir 은 세계 방향. NoiseSampler 는 256x256 타일 노이즈(RGBA 서로 다른 옥타브).
vec3 sunDirection(float az, float el) {
    float a = az * 6.2831853;
    float e = (el - 0.5) * 3.14159265;
    return vec3(sin(a) * cos(e), sin(e), cos(a) * cos(e));
}

float fbm2(sampler2D n, vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 5; i++) {
        v += a * texture(n, p).r;
        p = p * 2.03 + vec2(0.13, 0.27);
        a *= 0.5;
    }
    return v;
}

vec4 cloudLayer(sampler2D n, vec3 dir, vec3 camera, float cover, float t) {
    // 평면 구름: 위쪽 방향만
    if (dir.y < 0.015) {
        return vec4(0.0);
    }
    float h = (420.0) / dir.y;
    vec2 p = (dir.xz * h + camera.xz * 0.6) * 0.00058 + vec2(t * 0.0012, t * 0.0005);
    float d = fbm2(n, p);
    float d2 = fbm2(n, p * 2.7 + 3.1);
    float density = smoothstep(1.0 - cover, 1.0 - cover + 0.32, d * 0.75 + d2 * 0.35);
    float shade = clamp(0.3 + (d2 - 0.38) * 2.6 + (d - 0.45) * 1.2, 0.0, 1.0);
    float fade = smoothstep(0.015, 0.14, dir.y);
    return vec4(vec3(shade), density * fade);
}

#endif
