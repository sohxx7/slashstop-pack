#ifndef FILM_POST
#define FILM_POST

#include <minecraft:globals.glsl>
#include <film:params.glsl>

// ---- 데이터 버퍼 읽기 --------------------------------------------------------
float dec24(sampler2D s, ivec2 p, float range) {
    vec3 c = texelFetch(s, p, 0).rgb;
    int i = (int(c.r * 255.0 + 0.5) << 16) | (int(c.g * 255.0 + 0.5) << 8) | int(c.b * 255.0 + 0.5);
    return (float(i) / 16777215.0 * 2.0 - 1.0) * range;
}

float par(sampler2D s, ivec2 slotSub) {
    vec4 c = texelFetch(s, ivec2(slotSub.x, 1), 0);
    return slotSub.y == 0 ? c.g : c.b;
}

mat3 readView(sampler2D s) {
    return mat3(
        dec24(s, ivec2(0, 0), 2.0), dec24(s, ivec2(1, 0), 2.0), dec24(s, ivec2(2, 0), 2.0),
        dec24(s, ivec2(3, 0), 2.0), dec24(s, ivec2(4, 0), 2.0), dec24(s, ivec2(5, 0), 2.0),
        dec24(s, ivec2(6, 0), 2.0), dec24(s, ivec2(7, 0), 2.0), dec24(s, ivec2(8, 0), 2.0));
}

vec4 readProj(sampler2D s) {
    vec4 p = vec4(dec24(s, ivec2(9, 0), 32.0), dec24(s, ivec2(10, 0), 32.0), dec24(s, ivec2(11, 0), 8.0), dec24(s, ivec2(12, 0), 8.0));
    // 렌즈: 정점 셰이더가 적용한 화각을 같은 값으로 되짚는다
    float lensT = floor(par(s, P_LENS_HI) * 255.0 + 0.5) * 256.0 + floor(par(s, P_LENS_LO) * 255.0 + 0.5);
    if (lensT >= 400.0) {
        float f = 1.0 / tan(lensT / 200.0 * 3.14159265 / 180.0 * 0.5);
        float k = f / abs(p.y);
        p.x *= k;
        p.y *= k;
    }
    return p;
}

// ---- 기하 --------------------------------------------------------------------
// proj = (P00, P11, P22, P32), 깊이 d 는 역방향 Z(가까움=1, 하늘=0)
float viewZ(vec4 proj, float d) {
    return -proj.w / (d + proj.z);
}

vec3 viewPos(vec4 proj, vec2 uv, float d) {
    float z = viewZ(proj, d);
    vec2 ndc = uv * 2.0 - 1.0;
    return vec3(ndc.x * (-z) / proj.x, ndc.y * (-z) / proj.y, z);
}

vec3 viewRay(vec4 proj, vec2 uv) {
    vec2 ndc = uv * 2.0 - 1.0;
    return normalize(vec3(ndc.x / proj.x, ndc.y / proj.y, -1.0));
}

vec3 cameraWorld() {
    return vec3(CameraBlockPos) - CameraOffset;
}

// ---- 인코딩: 장면 기준 HDR을 8비트에 담는다 (0..8) ----------------------------
vec3 encHdr(vec3 c) {
    return sqrt(clamp(c / 8.0, 0.0, 1.0));
}

vec3 decHdr(vec3 e) {
    return e * e * 8.0;
}

vec3 srgb2lin(vec3 c) {
    return c * (c * (c * 0.305306011 + 0.682171111) + 0.012522878);
}

vec3 lin2srgb(vec3 c) {
    vec3 s1 = sqrt(c);
    vec3 s2 = sqrt(s1);
    vec3 s3 = sqrt(s2);
    return 0.585122381 * s1 + 0.783140355 * s2 - 0.368262736 * s3;
}

float luma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

float ign(vec2 p) {
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

// 초. GameTime은 다른 채널로 쓰므로 서버가 보내는 시계를 쓴다.
#define FILM_TIME(s) ((floor(par(s, P_CLOCK_HI) * 255.0 + 0.5) * 256.0 + floor(par(s, P_CLOCK_LO) * 255.0 + 0.5)) * 0.05)

vec3 hsv2rgb(float h, float s) {
    vec3 k = clamp(abs(fract(h + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
    return mix(vec3(1.0), k, s);
}

#endif
