#ifndef FILM_WORLD
#define FILM_WORLD

// 세계 변형 채널. 서버가 매 틱 게임 시간을 V*4 로 맞춘다. 클라이언트가 틱마다 올리는 +1은 4로 나눠 버린다.
// V 0..63   : 변형 없음(시계로만 쓴다)
// V 64..3099: 삭제 전선 = (V-64)*0.2 블록. 전선 밖의 청크 단면이 통째로 떠오른다
// V 3100..  : 세계 접기(인셉션). 앞쪽 지면이 위로 말려 올라간다
float film_channel() {
    return floor(GameTime * 24000.0 * 0.25 + 0.01);
}

// V 5950.. : 세계를 그리지 않는다(먼 컷 사이의 검은 화면)
bool film_black() {
    return film_channel() >= 5950.0;
}

float film_hash1(float x) {
    return fract(sin(x * 91.3458) * 47453.5453);
}

vec3 film_fold(vec3 rel, float worldY, float v) {
    float fold = (v - 3100.0) / 2899.0;
    float R = mix(600.0, 42.0, fold);
    float camToGround = worldY - rel.y - 64.0;
    float h = rel.y + camToGround + R;
    float an = rel.z / R;
    return vec3(rel.x, R - cos(an) * h - camToGround, sin(an) * h);
}

// 지형: section 은 청크 단면 원점의 절대 좌표
vec3 film_deform_section(vec3 rel, vec3 world, vec3 section) {
    float v = film_channel();
    if (v < 64.0) {
        return rel;
    }
    if (v >= 3100.0) {
        return film_fold(rel, world.y, v);
    }
    vec3 sw = section + 8.0;
    float front = (v - 64.0) * 0.2;
    float id = dot(floor(sw / 16.0), vec3(1.0, 57.0, 113.0));
    float r = film_hash1(id);
    float over = max(abs(sw.x), abs(sw.z - 262.0)) - front + (r - 0.5) * 22.0;
    if (over <= 0.0) {
        return rel;
    }
    vec3 local = world - sw;
    float spin = over * (r - 0.5) * 0.012;
    float cs = cos(spin);
    float sn = sin(spin);
    local.xz = mat2(cs, sn, -sn, cs) * local.xz;
    local.xy = mat2(cs, -sn, sn, cs) * local.xy;
    vec3 c = sw;
    c.y += over * (0.55 + r * 0.9) + over * over * 0.002;
    c.xz += vec2(film_hash1(id + 3.1) - 0.5, film_hash1(id + 7.7) - 0.5) * over * 0.35;
    return rel + (c + local - world);
}

// 엔티티: 청크 단면 대신 자기 위치 칸을 쓴다
vec3 film_deform(vec3 rel, vec3 world) {
    float v = film_channel();
    if (v < 64.0) {
        return rel;
    }
    if (v >= 3100.0) {
        return film_fold(rel, world.y, v);
    }
    return film_deform_section(rel, world, floor(world / 16.0) * 16.0);
}

#endif
