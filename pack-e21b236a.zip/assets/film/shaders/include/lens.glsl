#ifndef FILM_LENS
#define FILM_LENS

// 렌즈 채널. 서버가 플레이어 시계를 T(0..23999)로 맞추면 타임라인이 FogEnvironmentalStart=T/750 으로 바꿔 준다.
// T=0 이면 사용자 FOV 그대로. 그 밖에는 세로 화각 = T/200 도.
float film_lens_scale(mat4 proj) {
    if (proj[3][3] != 0.0) {
        return 1.0;     // 직교(GUI 등)
    }
    float t = FogEnvironmentalStart * 750.0;
    if (t < 400.0) {
        return 1.0;
    }
    float fov = t / 200.0 * 3.14159265 / 180.0;
    float f = 1.0 / tan(fov * 0.5);
    return f / abs(proj[1][1]);
}

#endif
