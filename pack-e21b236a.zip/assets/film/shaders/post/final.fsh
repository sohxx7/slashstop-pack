#version 330
#extension GL_ARB_separate_shader_objects : require

// 최종 합성: 렌즈(왜곡/수차), 심도 합성, 블룸, 톤매핑, 색보정, 입자, 막대.
#include <film:post.glsl>

uniform sampler2D SceneSampler;
uniform sampler2D DofSampler;
uniform sampler2D BloomSampler;
uniform sampler2D FlareSampler;
uniform sampler2D DepthSampler;
uniform sampler2D DataSampler;
uniform sampler2D PrevDataSampler;
uniform sampler2D NoiseSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 1) flat in vec4 proj;
layout(location = 2) flat in vec3 view0;
layout(location = 3) flat in vec3 view1;
layout(location = 4) flat in vec3 view2;

layout(location = 0) out vec4 fragColor;

vec3 aces(vec3 x) {
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

vec3 sceneAt(vec2 uv) {
    vec4 dof = texture(DofSampler, uv);
    vec3 sharp = decHdr(texture(SceneSampler, uv).rgb);
    float c = smoothstep(0.04, 0.3, dof.a);
    return mix(sharp, decHdr(dof.rgb), c);
}

mat3 prevView() {
    return mat3(
        dec24(PrevDataSampler, ivec2(0, 0), 2.0), dec24(PrevDataSampler, ivec2(1, 0), 2.0), dec24(PrevDataSampler, ivec2(2, 0), 2.0),
        dec24(PrevDataSampler, ivec2(3, 0), 2.0), dec24(PrevDataSampler, ivec2(4, 0), 2.0), dec24(PrevDataSampler, ivec2(5, 0), 2.0),
        dec24(PrevDataSampler, ivec2(6, 0), 2.0), dec24(PrevDataSampler, ivec2(7, 0), 2.0), dec24(PrevDataSampler, ivec2(8, 0), 2.0));
}

void main() {
    // params missing: 아직 표식을 못 받았다면 검은 화면
    if (texelFetch(DataSampler, ivec2(P_FADE.x, 1), 0).a < 0.5) {
        fragColor = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }
    float t = FILM_TIME(DataSampler);
    vec2 uv = texCoord;
    float aspect = ScreenSize.x / ScreenSize.y;

    // ---- 단체 사진: 화면이 흰 테두리 인화지 한 장으로 줄어든다 ----
    // 글자와 같은 640x360 가상 화면(위가 0)에서 잰다. 화면 비율이 달라도 글자 위치와 맞는다.
    float photo = par(DataSampler, P_PHOTO);
    float pe = photo * photo * (3.0 - 2.0 * photo);
    bool inContent = true;
    bool inPaper = true;
    vec2 dsg = vec2(0.0);
    vec2 paperMin = vec2(0.0);
    vec2 paperMax = vec2(0.0);
    if (photo > 0.001) {
        float u = min(ScreenSize.x / 640.0, ScreenSize.y / 360.0);
        vec2 off = (ScreenSize - vec2(640.0, 360.0) * u) * 0.5;
        vec2 px = texCoord * ScreenSize;
        dsg = (px - off) / u;
        dsg.y = 360.0 - dsg.y;
        vec2 fullMin = -off / u;
        vec2 fullMax = vec2(640.0, 360.0) + off / u;
        vec2 cMin = mix(fullMin, vec2(150.5, 50.5), pe);
        vec2 cMax = mix(fullMax, vec2(489.5, 276.5), pe);
        paperMin = cMin - vec2(11.0, 11.0) * pe;
        paperMax = cMax + vec2(11.0, 44.0) * pe;
        inContent = all(greaterThanEqual(dsg, cMin)) && all(lessThanEqual(dsg, cMax));
        inPaper = all(greaterThanEqual(dsg, paperMin)) && all(lessThanEqual(dsg, paperMax));
        // 사진에 담기는 장면: 가운데를 3:2로 자른다(막대 밖이던 위아래가 사진에서는 보인다)
        float cropH = mix(1.0, 0.92, pe);
        float cropW = mix(1.0, 0.92 * 1.5 / aspect, pe);
        vec2 rel = (dsg - cMin) / max(cMax - cMin, vec2(1e-3));
        rel.y = 1.0 - rel.y;
        uv = vec2(0.5) + (clamp(rel, 0.0, 1.0) - 0.5) * vec2(cropW, cropH);
    }

    // ---- 렌즈 변형 ----
    float roll = (par(DataSampler, P_ROLL) - 0.5) * 60.0 * 3.14159265 / 180.0;
    float zoom = 1.0 + par(DataSampler, P_ZOOM) * 2.0;
    vec2 c = (uv - 0.5) * vec2(aspect, 1.0);
    if (abs(roll) > 0.0005) {
        float cr = cos(roll);
        float sr = sin(roll);
        c = mat2(cr, sr, -sr, cr) * c;
        zoom *= 1.0 + abs(sin(roll)) * 0.9;
    }
    c /= zoom;
    float waveR = par(DataSampler, P_WAVE_R) * 1.6;
    float waveA = par(DataSampler, P_WAVE_A);
    if (waveA > 0.001) {
        float l = length(c);
        float dw = l - waveR;
        float band = exp(-dw * dw * 90.0);
        c *= 1.0 + band * waveA * 0.22 * sign(dw);
    }
    float glitch = par(DataSampler, P_GLITCH);
    uv = c / vec2(aspect, 1.0) + 0.5;
    if (glitch > 0.001) {
        float row = floor(uv.y * 40.0 + t * 3.0);
        float g = step(1.0 - glitch * 0.6, hash12(vec2(row, floor(t * 24.0))));
        uv.x += g * (hash12(vec2(row, floor(t * 31.0))) - 0.5) * 0.25 * glitch;
    }

    // ---- 카메라 모션 블러 ----
    vec3 color;
    float mb = par(DataSampler, P_MBLUR);
    float ca = par(DataSampler, P_ABERRATION) * 0.012;
    vec2 caDir = (uv - 0.5) * dot(uv - 0.5, uv - 0.5) * 4.0;
    vec3 center;
    center.r = sceneAt(uv + caDir * ca).r;
    center.g = sceneAt(uv).g;
    center.b = sceneAt(uv - caDir * ca).b;
    color = center;
    if (mb > 0.001) {
        float d = texture(DepthSampler, uv).r;
        mat3 V = mat3(view0, view1, view2);
        mat3 Vp = prevView();
        vec3 vp = d > 0.0 ? viewPos(proj, uv, d) : viewRay(proj, uv) * 2000.0;
        vec3 rel = transpose(V) * vp;
        // 이전 프레임 카메라 위치 차이는 저장된 값에서
        vec3 prevCam = vec3(dec24(PrevDataSampler, ivec2(0, 4), 4096.0), dec24(PrevDataSampler, ivec2(1, 4), 4096.0), dec24(PrevDataSampler, ivec2(2, 4), 4096.0));
        vec3 curCam = mod(cameraWorld() + 4096.0, 8192.0) - 4096.0;
        vec3 delta = curCam - prevCam;
        if (dot(delta, delta) > 64.0) { delta = vec3(0.0); }
        vec3 pv = Vp * (rel + delta);
        vec2 prevUv = vec2(pv.x * proj.x / -pv.z, pv.y * proj.y / -pv.z) * 0.5 + 0.5;
        vec2 vel = (prevUv - uv) * mb * 1.2;
        float vl = length(vel);
        if (vl > 0.0008 && pv.z < 0.0) {
            if (vl > 0.09) { vel *= 0.09 / vl; }
            float jit = ign(gl_FragCoord.xy);
            vec3 s = color;
            float w = 1.0;
            for (int i = 1; i < 8; i++) {
                float f = (float(i) - 0.5 + jit) / 7.0 - 0.5;
                s += decHdr(texture(SceneSampler, uv + vel * f).rgb);
                w += 1.0;
            }
            color = s / w;
        }
    }

    // ---- 블룸 ----
    vec3 bloom = decHdr(texture(BloomSampler, uv).rgb);
    vec3 flare = decHdr(texture(FlareSampler, uv).rgb);
    color += bloom * par(DataSampler, P_BLOOM) * 1.2;
    color += flare * par(DataSampler, P_FLARE) * 0.9;

    // ---- 노출, 색 ----
    float exposure = pow(2.0, (par(DataSampler, P_EXPOSURE) - 0.5) * 8.0);
    color *= exposure;
    color *= vec3(par(DataSampler, P_TINT_R), par(DataSampler, P_TINT_G), par(DataSampler, P_TINT_B)) * 2.0;

    // 회상 필름
    float memory = par(DataSampler, P_MEMORY);

    color = aces(color);

    // 그림자 색조 / 대비 / 채도 (디스플레이 공간)
    vec3 s = lin2srgb(max(color, vec3(0.0)));
    vec3 lift = (vec3(par(DataSampler, P_LIFT_R), par(DataSampler, P_LIFT_G), par(DataSampler, P_LIFT_B)) - 0.5) * 0.25;
    s += lift * (1.0 - s) * (1.0 - s);
    float con = (par(DataSampler, P_CONTRAST) - 0.5) * 2.0;
    s = mix(s, s * s * (3.0 - 2.0 * s), max(con, 0.0));
    s = mix(s, vec3(0.5), max(-con, 0.0));
    float sat = par(DataSampler, P_SATURATION) * 2.0;
    s = mix(vec3(luma(s)), s, sat);
    if (memory > 0.001) {
        float l = luma(s);
        vec3 sepia = vec3(l * 1.08 + 0.05, l * 0.97 + 0.02, l * 0.78);
        s = mix(s, sepia, memory * 0.85);
        s *= 1.0 - memory * 0.12 * (0.5 + 0.5 * sin(t * 14.0 + uv.y * 3.0));
        float scratch = step(0.997, hash12(vec2(floor(uv.x * 500.0), floor(t * 12.0))));
        s += scratch * memory * 0.25;
    }

    // ---- 프리즈 프레임: 강한 대비의 듀오톤 ----
    float frz = par(DataSampler, P_FREEZE);
    if (frz > 0.001) {
        float l = luma(s);
        l = smoothstep(0.08, 0.72, l);
        vec3 duo = mix(vec3(0.06, 0.03, 0.14), vec3(1.0, 0.72, 0.28), l);
        s = mix(s, duo, frz * 0.9);
    }

    // ---- 임팩트 프레임 ----
    float impact = par(DataSampler, P_IMPACT);
    if (impact > 0.001) {
        float l = luma(s);
        float cut = step(0.42 + 0.1 * sin(atan(c.y, c.x) * 40.0 + t * 90.0), l);
        vec3 ink = mix(vec3(0.02, 0.0, 0.0), vec3(1.0, 0.97, 0.9), cut);
        s = mix(s, ink, impact);
    }

    // ---- 비네트, 입자 ----
    vec2 q = texCoord - 0.5;
    float vig = par(DataSampler, P_VIGNETTE) * (1.0 - pe * 0.75);
    s *= 1.0 - vig * smoothstep(0.18, 0.95, dot(q, q) * 2.2);
    float grain = par(DataSampler, P_GRAIN);
    float n = hash12(gl_FragCoord.xy + fract(t * 7.13) * 317.0) - 0.5;
    s += n * grain * 0.11 * (1.0 - luma(s) * 0.6);

    // ---- 렌즈 물방울 ----
    float rain = par(DataSampler, P_LENS_RAIN) * (1.0 - pe);
    if (rain > 0.001) {
        vec2 p = texCoord * vec2(aspect, 1.0) * 11.0;
        p.y += t * 0.35;
        vec2 id = floor(p);
        vec2 f = fract(p) - 0.5;
        float r = hash12(id);
        f.y += sin(t * 0.8 + r * 19.0) * 0.2 * r;
        float drop = smoothstep(0.18 * r, 0.05 * r, length(f));
        s += drop * step(0.72, r) * rain * 0.16;
    }

    // ---- 인화지와 바탕 ----
    if (photo > 0.001) {
        if (inPaper && !inContent) {
            // 살짝 누런 인화지. 사진 둘레 안쪽은 아주 조금 어둡다
            float pn = hash12(floor(dsg * 3.0)) - 0.5;
            vec3 paper = vec3(0.925, 0.91, 0.875) + pn * 0.012;
            vec2 dOut = min(dsg - paperMin, paperMax - dsg);
            paper *= 0.94 + 0.06 * smoothstep(0.0, 2.5, min(dOut.x, dOut.y));
            s = mix(s, paper, pe);
        } else if (!inPaper) {
            // 어두운 책상. 오른쪽 아래로 그림자가 진다
            vec2 sc = clamp(dsg - vec2(3.0, 5.0), paperMin, paperMax);
            float sd = length(dsg - vec2(3.0, 5.0) - sc);
            float shadow = 1.0 - smoothstep(0.0, 14.0, sd);
            vec3 desk = vec3(0.035, 0.034, 0.04) * (1.0 - 0.6 * shadow);
            desk *= 1.0 - 0.5 * smoothstep(0.2, 0.9, length(q) * 1.3);
            s = mix(s, desk, pe);
        }
    }

    // ---- 페이드, 플래시 ----
    s = mix(s, vec3(1.0), par(DataSampler, P_FLASH));
    s *= 1.0 - par(DataSampler, P_FADE);

    // ---- 시네마스코프 막대 (사진에서는 인화지가 테두리다) ----
    float bars = par(DataSampler, P_BARS) * (1.0 - pe);
    if (bars > 0.001) {
        float target = mix(aspect, 2.39, bars);
        if (target > aspect) {
            float visible = aspect / target;
            float e = abs(texCoord.y - 0.5) * 2.0;
            float m = smoothstep(visible, visible + 2.0 / ScreenSize.y, e);
            s *= 1.0 - m;
        }
    }

    // 8비트 띠 없애기
    s += (ign(gl_FragCoord.xy) - 0.5) / 255.0;
    fragColor = vec4(clamp(s, 0.0, 1.0), 1.0);
}
