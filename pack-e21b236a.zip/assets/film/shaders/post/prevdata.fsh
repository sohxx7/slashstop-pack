#version 330
#extension GL_ARB_separate_shader_objects : require

// 이번 프레임의 카메라를 다음 프레임 모션 블러용으로 저장한다. 행 4에 카메라 위치.
#include <film:post.glsl>

uniform sampler2D DataSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

vec3 enc24(float v, float range) {
    float n = clamp(v / range * 0.5 + 0.5, 0.0, 1.0) * 16777215.0;
    int i = int(n + 0.5);
    return vec3(float((i >> 16) & 255), float((i >> 8) & 255), float(i & 255)) / 255.0;
}

void main() {
    ivec2 p = ivec2(gl_FragCoord.xy);
    if (p.y == 4) {
        vec3 cam = mod(cameraWorld() + 4096.0, 8192.0) - 4096.0;
        if (p.x < 3) {
            fragColor = vec4(enc24(cam[p.x], 4096.0), 1.0);
        } else {
            fragColor = vec4(0.0);
        }
    } else {
        fragColor = texelFetch(DataSampler, p, 0);
    }
}
