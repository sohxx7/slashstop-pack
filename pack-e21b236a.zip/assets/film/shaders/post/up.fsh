#version 330
#extension GL_ARB_separate_shader_objects : require

#include <film:post.glsl>

uniform sampler2D InSampler;    // 낮은 단계
uniform sampler2D BaseSampler;  // 같은 해상도 단계

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    vec2 t = 1.0 / vec2(textureSize(InSampler, 0));
    vec3 s = vec3(0.0);
    s += decHdr(texture(InSampler, texCoord + t * vec2(-1.0, -1.0)).rgb);
    s += decHdr(texture(InSampler, texCoord + t * vec2(0.0, -1.0)).rgb) * 2.0;
    s += decHdr(texture(InSampler, texCoord + t * vec2(1.0, -1.0)).rgb);
    s += decHdr(texture(InSampler, texCoord + t * vec2(-1.0, 0.0)).rgb) * 2.0;
    s += decHdr(texture(InSampler, texCoord).rgb) * 4.0;
    s += decHdr(texture(InSampler, texCoord + t * vec2(1.0, 0.0)).rgb) * 2.0;
    s += decHdr(texture(InSampler, texCoord + t * vec2(-1.0, 1.0)).rgb);
    s += decHdr(texture(InSampler, texCoord + t * vec2(0.0, 1.0)).rgb) * 2.0;
    s += decHdr(texture(InSampler, texCoord + t * vec2(1.0, 1.0)).rgb);
    vec3 up = s / 16.0;
    vec3 base = decHdr(texture(BaseSampler, texCoord).rgb);
    fragColor = vec4(encHdr(base + up * 0.85), 1.0);
}
