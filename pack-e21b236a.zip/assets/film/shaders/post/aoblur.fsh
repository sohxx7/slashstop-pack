#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    vec2 t = 1.0 / vec2(textureSize(InSampler, 0));
    float d0 = texture(DepthSampler, texCoord).r;
    float sum = 0.0;
    float w = 0.0;
    for (int y = -2; y <= 2; y++) {
        for (int x = -2; x <= 2; x++) {
            vec2 uv = texCoord + vec2(float(x), float(y)) * t;
            float d = texture(DepthSampler, uv).r;
            float g = 1.0 / (1.0 + abs(d - d0) * 900.0 / max(d0, 0.0005));
            sum += texture(InSampler, uv).r * g;
            w += g;
        }
    }
    float v = sum / max(w, 0.001);
    fragColor = vec4(v, v, v, 1.0);
}
