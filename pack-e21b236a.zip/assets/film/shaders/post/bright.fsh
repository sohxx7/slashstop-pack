#version 330
#extension GL_ARB_separate_shader_objects : require

#include <film:post.glsl>

uniform sampler2D InSampler;
uniform sampler2D DataSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    vec2 t = 1.0 / vec2(textureSize(InSampler, 0));
    // 13탭 다운샘플(반딧불 억제)
    vec3 a = decHdr(texture(InSampler, texCoord + t * vec2(-1.0, -1.0)).rgb);
    vec3 b = decHdr(texture(InSampler, texCoord + t * vec2(1.0, -1.0)).rgb);
    vec3 c = decHdr(texture(InSampler, texCoord + t * vec2(-1.0, 1.0)).rgb);
    vec3 d = decHdr(texture(InSampler, texCoord + t * vec2(1.0, 1.0)).rgb);
    vec3 e = decHdr(texture(InSampler, texCoord).rgb);
    vec3 col = (a + b + c + d) * 0.125 + e * 0.5;
    float th = par(DataSampler, P_BLOOM_TH) * 2.0;
    float l = max(col.r, max(col.g, col.b));
    float soft = clamp(l - th * 0.5, 0.0, th);
    soft = soft * soft / (2.0 * th + 0.0001);
    float k = max(soft, l - th) / max(l, 0.0001);
    fragColor = vec4(encHdr(col * k), 1.0);
}
