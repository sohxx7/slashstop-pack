#version 330
#extension GL_ARB_separate_shader_objects : require

#include <film:post.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    vec2 t = 1.0 / vec2(textureSize(InSampler, 0));
    vec3 s = decHdr(texture(InSampler, texCoord).rgb) * 4.0;
    s += decHdr(texture(InSampler, texCoord + t * vec2(-1.0, -1.0)).rgb);
    s += decHdr(texture(InSampler, texCoord + t * vec2(1.0, -1.0)).rgb);
    s += decHdr(texture(InSampler, texCoord + t * vec2(-1.0, 1.0)).rgb);
    s += decHdr(texture(InSampler, texCoord + t * vec2(1.0, 1.0)).rgb);
    fragColor = vec4(encHdr(s / 8.0), 1.0);
}
