#version 330
#extension GL_ARB_separate_shader_objects : require

// 젖은 바닥 반사: 위를 향한 면만, 깊이 버퍼로 레이마칭. 저해상도.
#include <film:post.glsl>

uniform sampler2D MainSampler;
uniform sampler2D DepthSampler;
uniform sampler2D DataSampler;
uniform sampler2D NoiseSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 1) flat in vec4 proj;
layout(location = 2) flat in vec3 view0;
layout(location = 3) flat in vec3 view1;
layout(location = 4) flat in vec3 view2;

layout(location = 0) out vec4 fragColor;

const int STEPS = 32;

void main() {
    fragColor = vec4(0.0);
    float wet = par(DataSampler, P_WET);
    if (wet <= 0.001) {
        return;
    }
    float d = texture(DepthSampler, texCoord).r;
    if (d <= 0.0) {
        return;
    }
    mat3 V = mat3(view0, view1, view2);
    mat3 Vi = transpose(V);
    vec3 P = viewPos(proj, texCoord, d);
    vec2 texel = 1.0 / vec2(textureSize(DepthSampler, 0));
    vec3 dx = viewPos(proj, texCoord + vec2(texel.x, 0.0), texture(DepthSampler, texCoord + vec2(texel.x, 0.0)).r) - P;
    vec3 dy = viewPos(proj, texCoord + vec2(0.0, texel.y), texture(DepthSampler, texCoord + vec2(0.0, texel.y)).r) - P;
    vec3 N = normalize(cross(dx, dy));
    vec3 Nw = Vi * N;
    if (Nw.y < 0.92) {
        return;
    }
    vec3 cam = cameraWorld();
    vec3 w = Vi * P + cam;
    // 물웅덩이 무늬: 세계 좌표에 붙은 잡음
    vec2 nuv = w.xz * 0.018;
    float t = FILM_TIME(DataSampler);
    float puddle = smoothstep(0.38, 0.6, texture(NoiseSampler, nuv).r);
    // 빗방울 파문: 법선을 흔든다
    vec2 ripple = (vec2(texture(NoiseSampler, w.xz * 0.21 + vec2(t * 0.11, 0.0)).g, texture(NoiseSampler, w.xz * 0.23 - vec2(0.0, t * 0.13)).b) - 0.5) * (0.018 + (1.0 - puddle) * 0.07);
    vec3 Nr = normalize(N + V * vec3(ripple.x, 0.0, ripple.y));
    vec3 I = normalize(P);
    vec3 R = reflect(I, Nr);
    if (R.z > -0.02) {
        // 카메라 쪽으로 돌아오는 반사는 화면 안에 없다
    }
    float fres = pow(1.0 - max(dot(-I, N), 0.0), 3.0) * 0.95 + 0.05;
    float strength = mix(0.28, 1.0, puddle) * fres * wet;
    float jitter = ign(gl_FragCoord.xy);
    float stepLen = 0.35 + (-P.z) * 0.016;
    vec3 q = P;
    vec3 hitCol = vec3(0.0);
    float hit = 0.0;
    for (int i = 0; i < STEPS; i++) {
        float s = stepLen * (1.0 + float(i) * 0.14);
        q += R * s * (i == 0 ? jitter + 0.2 : 1.0);
        if (q.z > -0.05) {
            break;
        }
        vec2 uv = vec2(q.x * proj.x / -q.z, q.y * proj.y / -q.z) * 0.5 + 0.5;
        if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
            break;
        }
        float sd = texture(DepthSampler, uv).r;
        float sz = sd > 0.0 ? viewZ(proj, sd) : -100000.0;
        float diff = sz - q.z;
        if (diff > 0.0 && diff < s * 2.0 + 0.6) {
            vec4 m = texture(MainSampler, uv);
            // 발광 재질만 밝게, 나머지는 어둡게 비친다
            float e = m.a < 0.42 ? 6.0 : (m.a < 0.99 ? 0.5 : 0.12);
            hitCol = srgb2lin(m.rgb) * e;
            vec2 edge = abs(uv - 0.5) * 2.0;
            hit = (1.0 - smoothstep(0.75, 1.0, max(edge.x, edge.y))) * (1.0 - float(i) / float(STEPS));
            break;
        }
    }
    fragColor = vec4(encHdr(hitCol), clamp(hit * strength, 0.0, 1.0));
}
