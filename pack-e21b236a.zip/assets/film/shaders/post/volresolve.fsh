#version 330
#extension GL_ARB_separate_shader_objects : require

// 체적광 잡음 제거: 3x3 블러 + 시간 누적
uniform sampler2D InSampler;
uniform sampler2D HistSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    vec2 t = 1.0 / vec2(textureSize(InSampler, 0));
    vec3 sum = vec3(0.0);
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            sum += texture(InSampler, texCoord + vec2(float(x), float(y)) * t).rgb;
        }
    }
    vec3 cur = sum / 9.0;
    vec3 hist = texture(HistSampler, texCoord).rgb;
    fragColor = vec4(mix(hist, cur, 0.22), 1.0);
}
