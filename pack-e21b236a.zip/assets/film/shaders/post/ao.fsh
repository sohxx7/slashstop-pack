#version 330
#extension GL_ARB_separate_shader_objects : require

#include <film:post.glsl>

uniform sampler2D DepthSampler;
uniform sampler2D DataSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 1) flat in vec4 proj;

layout(location = 0) out vec4 fragColor;

const int N = 12;

void main() {
    float d = texture(DepthSampler, texCoord).r;
    if (d <= 0.0) {
        fragColor = vec4(1.0);
        return;
    }
    vec3 P = viewPos(proj, texCoord, d);
    vec2 texel = 1.0 / vec2(textureSize(DepthSampler, 0));
    vec3 dx = viewPos(proj, texCoord + vec2(texel.x, 0.0), texture(DepthSampler, texCoord + vec2(texel.x, 0.0)).r) - P;
    vec3 dx2 = P - viewPos(proj, texCoord - vec2(texel.x, 0.0), texture(DepthSampler, texCoord - vec2(texel.x, 0.0)).r);
    vec3 dy = viewPos(proj, texCoord + vec2(0.0, texel.y), texture(DepthSampler, texCoord + vec2(0.0, texel.y)).r) - P;
    vec3 dy2 = P - viewPos(proj, texCoord - vec2(0.0, texel.y), texture(DepthSampler, texCoord - vec2(0.0, texel.y)).r);
    if (dot(dx2, dx2) < dot(dx, dx)) { dx = dx2; }
    if (dot(dy2, dy2) < dot(dy, dy)) { dy = dy2; }
    vec3 Nn = normalize(cross(dx, dy));

    float radius = 1.1;      // 블록
    float z = -P.z;
    vec2 scale = vec2(proj.x, proj.y) * 0.5 * radius / z;
    float rnd = ign(gl_FragCoord.xy) * 6.2831853;
    float occ = 0.0;
    for (int i = 0; i < N; i++) {
        float fi = (float(i) + 0.5) / float(N);
        float a = rnd + fi * 6.2831853 * 3.0;
        vec2 off = vec2(cos(a), sin(a)) * sqrt(fi) * scale;
        vec2 uv = texCoord + off;
        float sd = texture(DepthSampler, uv).r;
        vec3 S = viewPos(proj, uv, sd);
        vec3 v = S - P;
        float vl = length(v);
        float ndv = max(dot(Nn, v / max(vl, 0.0001)) - 0.08, 0.0);
        float falloff = clamp(1.0 - vl / (radius * 1.8), 0.0, 1.0);
        occ += ndv * falloff;
    }
    occ = clamp(1.0 - occ / float(N) * 2.4, 0.0, 1.0);
    fragColor = vec4(occ, occ, occ, 1.0);
}
