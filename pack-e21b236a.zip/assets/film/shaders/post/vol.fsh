#version 330
#extension GL_ARB_separate_shader_objects : require

// 체적광: 해/달빛 기둥과 동적 조명의 빛 번짐을 레이마칭한다. 저해상도.
#include <film:post.glsl>
#include <film:sky.glsl>

uniform sampler2D DepthSampler;
uniform sampler2D DataSampler;
uniform sampler2D NoiseSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 1) flat in vec4 proj;
layout(location = 2) flat in vec3 view0;
layout(location = 3) flat in vec3 view1;
layout(location = 4) flat in vec3 view2;

layout(location = 0) out vec4 fragColor;

const int STEPS = 18;

float fogDensity(vec3 w, float dens, float hfall, float y0, float t) {
    float h = exp(-max(w.y - y0, -8.0) * hfall);
    vec2 uv = w.xz * 0.012 + vec2(t * 0.012, t * 0.007);
    float n = texture(NoiseSampler, uv).g * 0.7 + texture(NoiseSampler, uv * 3.1 + w.y * 0.01).b * 0.5;
    return dens * h * (0.45 + n);
}

void main() {
    float scatter = par(DataSampler, P_SCATTER);
    float depth = texture(DepthSampler, texCoord).r;
    if (scatter <= 0.001) {
        fragColor = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }
    mat3 V = mat3(view0, view1, view2);
    mat3 Vi = transpose(V);
    vec3 vr = viewRay(proj, texCoord);
    vec3 dir = Vi * vr;
    float maxDist = 220.0;
    float dist = maxDist;
    if (depth > 0.0) {
        dist = min(maxDist, length(viewPos(proj, texCoord, depth)));
    }
    vec3 cam = cameraWorld();

    float dv = par(DataSampler, P_FOG_DENS);
    float dens = dv * dv * 0.2;
    float hfall = par(DataSampler, P_FOG_HFALL) * 0.2;
    float y0 = (par(DataSampler, P_FOG_Y) - 0.5) * 512.0;
    float t = FILM_TIME(DataSampler);
    vec3 sunDir = sunDirection(par(DataSampler, P_SUN_AZ), par(DataSampler, P_SUN_EL));
    vec3 sunCol = vec3(par(DataSampler, P_SUN_R), par(DataSampler, P_SUN_G), par(DataSampler, P_SUN_B)) * 8.0;
    float g = 0.55;
    float cosT = dot(dir, sunDir);
    float phase = (1.0 - g * g) / pow(1.0 + g * g - 2.0 * g * cosT, 1.5) * 0.08 + 0.03;

    vec3 lp[8];
    vec3 lc[8];
    vec4 la[8];
    int n = 0;
    for (int i = 0; i < 8; i++) {
        vec4 tail = texelFetch(DataSampler, ivec2(i * 4 + 3, 2), 0);
        if (tail.a > 0.5 && tail.b > 0.0) {
            lp[n] = vec3(dec24(DataSampler, ivec2(i * 4, 2), 4096.0), dec24(DataSampler, ivec2(i * 4 + 1, 2), 4096.0), dec24(DataSampler, ivec2(i * 4 + 2, 2), 4096.0));
            vec4 hs = texelFetch(DataSampler, ivec2(64 + i, 1), 0);
            float inten = tail.b * tail.b * 64.0;
            lc[n] = hsv2rgb(hs.g, hs.b) * inten;
            la[n] = vec4(0.0, 0.0, 0.0, tail.g * 64.0);    // xyz=조준 방향, w=반경
            vec4 aimTail = texelFetch(DataSampler, ivec2(i * 4 + 3, 3), 0);
            if (aimTail.a > 0.5) {
                vec3 ap = vec3(dec24(DataSampler, ivec2(i * 4, 3), 4096.0), dec24(DataSampler, ivec2(i * 4 + 1, 3), 4096.0), dec24(DataSampler, ivec2(i * 4 + 2, 3), 4096.0));
                la[n].xyz = normalize(ap - lp[n]) * mix(0.995, 0.6, aimTail.g);
            }
            n++;
        }
    }

    float jitter = ign(gl_FragCoord.xy + vec2(mod(t * 60.0, 64.0)));
    float stepLen = dist / float(STEPS);
    vec3 acc = vec3(0.0);
    float trans = 1.0;
    for (int i = 0; i < STEPS; i++) {
        float s = (float(i) + jitter) * stepLen;
        vec3 rel = dir * s;
        vec3 w = cam + rel;
        float rho = fogDensity(w, dens, hfall, y0, t);
        vec3 inscat = sunCol * phase;
        for (int l = 0; l < n; l++) {
            vec3 toL = lp[l] - rel;
            float d2 = dot(toL, toL);
            float r = la[l].w;
            float att = clamp(1.0 - d2 / (r * r), 0.0, 1.0);
            att = att * att;
            float aimLen = dot(la[l].xyz, la[l].xyz);
            if (aimLen > 0.01) {
                // 조준 벡터 길이에 콘 코사인을 담았다
                float cone = sqrt(aimLen);
                float c = dot(-toL / sqrt(max(d2, 0.001)), la[l].xyz / cone);
                att *= smoothstep(cone, min(cone + 0.02, 1.0), c) * 2.0 / (1.0 + d2 * 0.02);
            } else {
                att /= 1.0 + d2 * 0.08;
            }
            inscat += lc[l] * att * (aimLen > 0.01 ? 0.42 : 0.06);
        }
        float ext = rho * stepLen;
        acc += inscat * rho * stepLen * trans;
        trans *= exp(-ext);
    }
    fragColor = vec4(encHdr(acc * scatter * 3.0), 1.0);
}
