#version 330
#extension GL_ARB_separate_shader_objects : require

// 아웃라인 버퍼의 데이터 픽셀을 안정된 타깃으로 옮긴다. 파라미터 행은 값이 빠진 프레임이면 직전 값을 쓴다.
uniform sampler2D RawSampler;
uniform sampler2D PrevSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    ivec2 p = ivec2(gl_FragCoord.xy);
    if (p.y > 5 || p.x > 80) {
        fragColor = vec4(0.0);
        return;
    }
    vec4 c = texelFetch(RawSampler, p, 0);
    if (p.y <= 1 && c.a < 0.5) {
        c = texelFetch(PrevSampler, p, 0);
    }
    fragColor = c;
}
