#version 330
#extension GL_ARB_separate_shader_objects : require

// 심도: 저해상도에서 원형 보케 수집. 알파에 착란원 크기를 담아 최종 합성이 섞는다.
#include <film:post.glsl>

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;
uniform sampler2D DataSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 1) flat in vec4 proj;

layout(location = 0) out vec4 fragColor;

const int SAMPLES = 28;

float coc(float d, float focus, float aperture) {
    float z = d > 0.0 ? -viewZ(proj, d) : 4000.0;
    float c = abs(z - focus) / max(z, 0.05) * aperture;
    return clamp(c, 0.0, 1.0);
}

void main() {
    float fv = par(DataSampler, P_FOCUS);
    if (fv <= 0.001) {
        fragColor = vec4(texture(InSampler, texCoord).rgb, 0.0);
        return;
    }
    float focus = pow(2.0, fv * 9.0) - 1.0;
    float ap = par(DataSampler, P_APERTURE) * 3.0;
    float d0 = texture(DepthSampler, texCoord).r;
    float c0 = coc(d0, focus, ap);
    float maxR = 0.022;     // 화면 높이 비율
    vec2 aspect = vec2(ScreenSize.y / ScreenSize.x, 1.0);
    vec3 sum = decHdr(texture(InSampler, texCoord).rgb);
    float w = 1.0;
    float rot = ign(gl_FragCoord.xy) * 6.2831853;
    float z0 = d0 > 0.0 ? -viewZ(proj, d0) : 4000.0;
    for (int i = 0; i < SAMPLES; i++) {
        float fi = (float(i) + 0.5) / float(SAMPLES);
        float a = rot + fi * 6.2831853 * 7.0;
        float r = sqrt(fi);
        vec2 uv = texCoord + vec2(cos(a), sin(a)) * r * maxR * aspect;
        float d = texture(DepthSampler, uv).r;
        float c = coc(d, focus, ap);
        float z = d > 0.0 ? -viewZ(proj, d) : 4000.0;
        // 앞쪽 흐림은 번져 나오고, 뒤쪽 흐림은 초점면 앞으로 새지 않게 한다
        float use = z < z0 ? c : min(c, c0 + 0.08);
        float g = smoothstep(r - 0.1, r + 0.1, use);
        sum += decHdr(texture(InSampler, uv).rgb) * g;
        w += g;
    }
    fragColor = vec4(encHdr(sum / w), c0);
}
