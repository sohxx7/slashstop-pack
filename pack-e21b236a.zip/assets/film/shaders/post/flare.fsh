#version 330
#extension GL_ARB_separate_shader_objects : require

// 아나모픽 가로 번짐: 밝은 빛을 옆으로 길게 끌고 푸르게 물들인다
#include <film:post.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    vec2 t = 1.0 / vec2(textureSize(InSampler, 0));
    vec3 s = vec3(0.0);
    float w = 0.0;
    for (int i = -14; i <= 14; i++) {
        float g = exp(-abs(float(i)) * 0.22);
        s += decHdr(texture(InSampler, texCoord + vec2(float(i) * t.x * 3.0, 0.0)).rgb) * g;
        w += g;
    }
    fragColor = vec4(encHdr(s / w * vec3(0.55, 0.72, 1.25)), 1.0);
}
