#version 330
#extension GL_ARB_separate_shader_objects : require

#include <film:post.glsl>

uniform sampler2D DataSampler;

layout(location = 0) out vec2 texCoord;
layout(location = 1) flat out vec4 proj;
layout(location = 2) flat out vec3 view0;
layout(location = 3) flat out vec3 view1;
layout(location = 4) flat out vec3 view2;

void main() {
    vec2 uv = vec2((gl_VertexIndex << 1) & 2, gl_VertexIndex & 2);
    gl_Position = vec4(uv * 2.0 - 1.0, 0.0, 1.0);
    texCoord = uv;
    proj = readProj(DataSampler);
    mat3 v = readView(DataSampler);
    view0 = v[0];
    view1 = v[1];
    view2 = v[2];
}
