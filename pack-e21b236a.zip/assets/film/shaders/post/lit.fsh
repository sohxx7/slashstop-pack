#version 330
#extension GL_ARB_separate_shader_objects : require

// 조명 합성: 메인 버퍼를 G버퍼로 읽어 장면 기준(HDR) 색을 만든다.
// RGB = 알베도 x 정점 AO x 하늘빛 모양, A = 1-0.5*블록빛 (A<0.5 면 발광)
#include <film:post.glsl>
#include <film:sky.glsl>

uniform sampler2D MainSampler;
uniform sampler2D DepthSampler;
uniform sampler2D DataSampler;
uniform sampler2D AoSampler;
uniform sampler2D VolSampler;
uniform sampler2D NoiseSampler;
uniform sampler2D SkyTextSampler;
uniform sampler2D SsrSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 1) flat in vec4 proj;
layout(location = 2) flat in vec3 view0;
layout(location = 3) flat in vec3 view1;
layout(location = 4) flat in vec3 view2;

layout(location = 0) out vec4 fragColor;

vec3 skyColor(vec3 dir, vec3 cam, float t) {
    vec3 zen = vec3(par(DataSampler, P_ZEN_R), par(DataSampler, P_ZEN_G), par(DataSampler, P_ZEN_B));
    vec3 hor = vec3(par(DataSampler, P_HOR_R), par(DataSampler, P_HOR_G), par(DataSampler, P_HOR_B));
    zen = zen * zen * 2.0;
    hor = hor * hor * 3.0;
    float h = clamp(dir.y, -0.08, 1.0);
    vec3 c = mix(hor, zen, pow(clamp(h, 0.0, 1.0), 0.42));
    float under = par(DataSampler, P_UNDER);
    if (dir.y < 0.0) {
        c = mix(c, hor * 0.5, clamp(-dir.y * 12.0, 0.0, 1.0));
        c = mix(c, vec3(0.004, 0.003, 0.008), under * smoothstep(0.0, 0.2, -dir.y));
    }

    vec3 sunDir = sunDirection(par(DataSampler, P_SUN_AZ), par(DataSampler, P_SUN_EL));
    vec3 sunCol = vec3(par(DataSampler, P_SUN_R), par(DataSampler, P_SUN_G), par(DataSampler, P_SUN_B)) * 8.0;
    float cs = max(dot(dir, sunDir), 0.0);
    c += sunCol * (pow(cs, 8.0) * 0.05 + pow(cs, 96.0) * 0.25);

    // 별
    float stars = par(DataSampler, P_STARS);
    if (stars > 0.001 && (dir.y > -0.02 || under > 0.5)) {
        vec3 d = dir * 220.0;
        vec3 id = floor(d);
        float rnd = fract(sin(dot(id, vec3(12.9898, 78.233, 37.719))) * 43758.5453);
        if (rnd > 0.9965) {
            vec3 f = fract(d) - 0.5;
            float tw = 0.65 + 0.35 * sin(t * (2.0 + rnd * 3.0) + rnd * 91.0);
            c += vec3(0.8, 0.88, 1.0) * smoothstep(0.42, 0.02, length(f)) * stars * tw * (rnd - 0.9965) * 800.0 * 0.6;
        }
    }

    // 달
    float moon = par(DataSampler, P_MOON);
    if (moon > 0.001) {
        vec3 md = normalize(sunDir);
        float m = dot(dir, md);
        float disk = smoothstep(0.99955, 0.9997, m);
        if (disk > 0.0) {
            vec3 tan1 = normalize(cross(md, vec3(0.0, 1.0, 0.0)));
            vec3 tan2 = cross(md, tan1);
            vec2 uv = vec2(dot(dir, tan1), dot(dir, tan2)) * 14.0;
            float crater = texture(NoiseSampler, uv + 0.5).r * 0.65 + 0.35;
            c = mix(c, vec3(0.92, 0.95, 1.0) * crater * 3.2 * moon, disk);
        }
        c += vec3(0.5, 0.6, 0.8) * pow(max(m, 0.0), 900.0) * moon * 0.6;
        c += vec3(0.3, 0.38, 0.55) * pow(max(m, 0.0), 40.0) * moon * 0.05;
    }

    // 구름
    float cover = par(DataSampler, P_CLOUDS);
    if (cover > 0.001) {
        vec4 cl = cloudLayer(NoiseSampler, dir, cam, cover, t);
        float lit = par(DataSampler, P_CLOUD_LIT);
        float flash = par(DataSampler, P_LIGHTNING);
        vec3 col = mix(zen * 0.3 + hor * 0.15, hor * 1.2 + sunCol * 0.1, cl.r) * (0.4 + lit * 2.2);
        col += vec3(0.75, 0.82, 1.0) * flash * flash * 6.0 * (0.25 + cl.r);
        c = mix(c, col, cl.a);
    }

    // 하늘 공지(글자 텍스처를 하늘에 투영)
    float st = par(DataSampler, P_SKYTEXT);
    if (st > 0.001 && dir.y > 0.02) {
        // 정면(+Z 방향 기준) 평면에 투영
        vec3 sd = normalize(vec3(0.0, tan(par(DataSampler, P_SKY_EL) * 1.5707), 1.0));
        vec3 sx = normalize(cross(vec3(0.0, 1.0, 0.0), sd));
        vec3 sy = cross(sd, sx);
        float dd = dot(dir, sd);
        if (dd > 0.05) {
            vec2 sp = vec2(dot(dir, sx), dot(dir, sy)) / dd;
            vec2 uv = vec2(0.5 - sp.x * 1.55, 0.5 - sp.y * 6.2);
            if (uv.x > 0.0 && uv.x < 1.0 && uv.y > 0.0 && uv.y < 1.0) {
                vec4 tx = texture(SkyTextSampler, uv);
                float heat = 0.75 + 0.25 * sin(t * 1.7 + uv.x * 13.0);
                c = mix(c, vec3(1.0, 0.86, 0.5) * 2.4 * heat, tx.r * st);
                c += vec3(1.0, 0.5, 0.14) * tx.g * st * 0.55;
            }
        }
    }

    // 먼 도시 실루엣: 지평선 위 두 겹
    float skyline = par(DataSampler, P_SKYLINE);
    if (skyline > 0.001 && dir.y > -0.05 && dir.y < 0.3) {
        float az = atan(dir.x, dir.z);
        for (int i = 0; i < 2; i++) {
            float k = i == 0 ? 90.0 : 170.0;
            float xx = az * k + float(i) * 13.0;
            float id = floor(xx);
            float h = (i == 0 ? 0.075 : 0.045) * (0.35 + fract(sin(id * 12.9898) * 43758.5453) * fract(sin(id * 4.1414) * 1234.5678) * 2.2);
            if (dir.y < h) {
                vec3 base = mix(hor * 0.32, hor * 0.5, float(i));
                // 창 불빛
                float wx = floor(fract(xx) * 6.0);
                float wy = floor(dir.y * 420.0);
                float lit = fract(sin(id * 3.1 + wx * 17.0 + wy * 7.3) * 9631.17);
                if (lit > 0.988 && fract(fract(xx) * 6.0) < 0.6 && fract(dir.y * 420.0) < 0.6) {
                    base += mix(vec3(1.0, 0.72, 0.42), vec3(0.5, 0.8, 1.0), step(0.985, lit)) * (i == 0 ? 0.5 : 0.3);
                }
                c = mix(c, base, skyline);
                break;
            }
        }
    }
    float hglow = par(DataSampler, P_HORIZON_GLOW);
    if (hglow > 0.001) {
        c += vec3(1.0, 0.45, 0.2) * exp(-abs(dir.y) * 18.0) * hglow * 0.8;
    }

    // 공허
    float vd = par(DataSampler, P_VOID);
    if (vd > 0.001) {
        c = mix(c, vec3(0.0005, 0.0005, 0.001), vd);
    }
    return c;
}

void main() {
    vec4 gb = texture(MainSampler, texCoord);
    float depth = texture(DepthSampler, texCoord).r;
    mat3 V = mat3(view0, view1, view2);
    mat3 Vi = transpose(V);
    vec3 vr = viewRay(proj, texCoord);
    vec3 dir = Vi * vr;
    vec3 cam = cameraWorld();
    float t = FILM_TIME(DataSampler);

    vec3 fogCol = vec3(par(DataSampler, P_FOG_R), par(DataSampler, P_FOG_G), par(DataSampler, P_FOG_B));
    fogCol = fogCol * fogCol * 2.0;

    vec3 color;
    float dist;
    if (depth <= 0.0) {
        color = skyColor(dir, cam, t);
        dist = 100000.0;
    } else {
        vec3 vp = viewPos(proj, texCoord, depth);
        dist = length(vp);
        vec3 rel = Vi * vp;
        vec2 texel = 1.0 / vec2(textureSize(MainSampler, 0));
        // 법선 복원: 네 방향 중 기울기가 작은 쪽
        float dl = texture(DepthSampler, texCoord - vec2(texel.x, 0.0)).r;
        float dr = texture(DepthSampler, texCoord + vec2(texel.x, 0.0)).r;
        float du = texture(DepthSampler, texCoord + vec2(0.0, texel.y)).r;
        float dd = texture(DepthSampler, texCoord - vec2(0.0, texel.y)).r;
        vec3 ddx = abs(dl - depth) < abs(dr - depth) ? vp - viewPos(proj, texCoord - vec2(texel.x, 0.0), dl) : viewPos(proj, texCoord + vec2(texel.x, 0.0), dr) - vp;
        vec3 ddy = abs(dd - depth) < abs(du - depth) ? vp - viewPos(proj, texCoord - vec2(0.0, texel.y), dd) : viewPos(proj, texCoord + vec2(0.0, texel.y), du) - vp;
        vec3 nv = normalize(cross(ddx, ddy));
        vec3 N = Vi * nv;

        vec3 albedo = srgb2lin(gb.rgb);
        float a = gb.a;
        float block = a >= 0.42 ? clamp((1.0 - a) * 2.0, 0.0, 1.0) : 0.0;
        float emissive = a < 0.42 ? 1.0 : smoothstep(0.93, 1.0, max(gb.r, max(gb.g, gb.b)));

        float aoAmt = par(DataSampler, P_AO);
        float ao = mix(1.0, texture(AoSampler, texCoord).r, aoAmt);

        vec3 amb = vec3(par(DataSampler, P_AMB_R), par(DataSampler, P_AMB_G), par(DataSampler, P_AMB_B)) * 4.0;
        amb *= amb;
        vec3 L = amb * ao * (0.72 + 0.28 * N.y);

        vec3 blockCol = vec3(par(DataSampler, P_BLOCK_R), par(DataSampler, P_BLOCK_G), par(DataSampler, P_BLOCK_B));
        float flicker = 1.0 - par(DataSampler, P_FLICKER) * (0.5 + 0.5 * sin(t * 37.0 + 2.0 * sin(t * 11.0)));
        L += blockCol * par(DataSampler, P_BLOCK_GAIN) * 8.0 * block * block * mix(1.0, ao, 0.6) * flicker;

        vec3 sunDir = sunDirection(par(DataSampler, P_SUN_AZ), par(DataSampler, P_SUN_EL));
        vec3 sunCol = vec3(par(DataSampler, P_SUN_R), par(DataSampler, P_SUN_G), par(DataSampler, P_SUN_B)) * 8.0;
        float ndl = max(dot(N, sunDir), 0.0);
        if (ndl > 0.0 && dot(sunCol, sunCol) > 0.0001) {
            // 화면 공간 접촉 그림자
            vec3 svd = V * sunDir;
            float shadow = 1.0;
            float jitter = ign(gl_FragCoord.xy);
            for (int i = 1; i <= 10; i++) {
                float s = (float(i) + jitter) * (0.09 + dist * 0.004) * (1.0 + float(i) * 0.35);
                vec3 q = vp + svd * s;
                vec2 uv = vec2(q.x * proj.x / -q.z, q.y * proj.y / -q.z) * 0.5 + 0.5;
                if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) { break; }
                float sd = texture(DepthSampler, uv).r;
                if (sd <= 0.0) { continue; }
                float sz = viewZ(proj, sd);
                float diff = sz - q.z;
                if (diff > 0.04 && diff < 3.0 + s) {
                    shadow = 0.0;
                    break;
                }
            }
            L += sunCol * ndl * shadow;
        }

        // 동적 조명
        for (int i = 0; i < 8; i++) {
            vec4 tail = texelFetch(DataSampler, ivec2(i * 4 + 3, 2), 0);
            if (tail.a < 0.5 || tail.b <= 0.0) { continue; }
            vec3 lp = vec3(dec24(DataSampler, ivec2(i * 4, 2), 4096.0), dec24(DataSampler, ivec2(i * 4 + 1, 2), 4096.0), dec24(DataSampler, ivec2(i * 4 + 2, 2), 4096.0));
            vec3 toL = lp - rel;
            float d2 = dot(toL, toL);
            float r = tail.g * 64.0;
            float att = clamp(1.0 - d2 / (r * r), 0.0, 1.0);
            if (att <= 0.0) { continue; }
            att = att * att;
            vec3 ln = toL / sqrt(max(d2, 0.0001));
            vec4 aimTail = texelFetch(DataSampler, ivec2(i * 4 + 3, 3), 0);
            if (aimTail.a > 0.5) {
                vec3 ap = vec3(dec24(DataSampler, ivec2(i * 4, 3), 4096.0), dec24(DataSampler, ivec2(i * 4 + 1, 3), 4096.0), dec24(DataSampler, ivec2(i * 4 + 2, 3), 4096.0));
                float cone = mix(0.995, 0.6, aimTail.g);
                float c = dot(-ln, normalize(ap - lp));
                att *= smoothstep(cone, min(cone + 0.03, 1.0), c) * 2.5 / (1.0 + d2 * 0.025);
            } else {
                att /= 1.0 + d2 * 0.12;
            }
            vec4 hs = texelFetch(DataSampler, ivec2(64 + i, 1), 0);
            float inten = tail.b * tail.b * 64.0;
            float diff = max(dot(N, ln), 0.0) * 0.85 + 0.15;
            L += hsv2rgb(hs.g, hs.b) * inten * att * diff;
        }

        color = albedo * L;
        float eg = a < 0.2 ? 2.6 : par(DataSampler, P_EMISSIVE) * 16.0;
        color = mix(color, albedo * eg, emissive);
        // 홀로그램 표식(B=1, R 낮음): 장면 밝기와 상관없이 일정하게 빛난다
        if (gb.b > 0.97 && gb.r < 0.4 && gb.g < 0.86 && a > 0.99) {
            color = srgb2lin(vec3(gb.r, gb.g, clamp(gb.g * 1.12 + 0.12, 0.0, 1.0))) * 1.7;
        }

        // 안개
        float dv = par(DataSampler, P_FOG_DENS);
        float dens = dv * dv * 0.2;
        if (dens > 0.0) {
            float hfall = par(DataSampler, P_FOG_HFALL) * 0.2 + 0.0001;
            float y0 = (par(DataSampler, P_FOG_Y) - 0.5) * 512.0;
            float yc = cam.y - y0;
            float h0 = exp(-max(yc, -16.0) * hfall);
            float k = hfall * dir.y * dist;
            float integ = abs(k) > 0.0005 ? (1.0 - exp(-k)) / k : 1.0;
            float fog = 1.0 - exp(-dens * h0 * integ * dist);
            color = mix(color, fogCol * (amb * 0.6 + 0.05), fog);
        }
    }

    // 빗물 반사
    if (depth > 0.0) {
        vec4 ssr = texture(SsrSampler, texCoord);
        color = mix(color, decHdr(ssr.rgb), ssr.a);
    }

    // 체적광
    vec3 vol = decHdr(texture(VolSampler, texCoord).rgb);
    color += vol;

    // 삭제 전선: 중심(0,262)을 둘러싼 거대한 빛의 벽. 그 너머는 없다.
    float wallD = floor(par(DataSampler, P_WALL_HI) * 255.0 + 0.5) * 256.0 + floor(par(DataSampler, P_WALL_LO) * 255.0 + 0.5);
    float wallG = par(DataSampler, P_WALL_GLOW);
    if (wallG > 0.001 && wallD > 0.0) {
        vec2 ro = cam.xz - vec2(0.0, 262.0);
        vec2 rd = dir.xz;
        // 축 정렬 사각형 내부에서 밖으로 나가는 교차
        vec2 inv = 1.0 / (abs(rd) + 1e-5);
        vec2 tt = (vec2(wallD) - sign(rd) * ro) * inv;
        float hit = min(tt.x, tt.y);
        if (hit > 0.0) {
            float sceneDist = depth > 0.0 ? dist : 1e9;
            vec3 pw = cam + dir * hit;
            vec2 wu = vec2(tt.x < tt.y ? pw.z : pw.x, pw.y);
            float n1 = texture(NoiseSampler, vec2(wu.x * 0.0035, wu.y * 0.0006 - t * 0.03)).r;
            float n2 = texture(NoiseSampler, vec2(wu.x * 0.017, wu.y * 0.0016 - t * 0.11)).g;
            float n3 = texture(NoiseSampler, vec2(wu.x * 0.061, wu.y * 0.0042 - t * 0.38)).b;
            float n4 = texture(NoiseSampler, vec2(wu.x * 0.19, wu.y * 0.009 - t * 0.7)).r;
            float streak = n1 * 0.16 + n2 * 0.42 + n3 * 0.42 + n4 * 0.16;
            float fade = exp(-max(pw.y - 60.0, 0.0) * 0.0035);
            float band = exp(-abs(pw.y - 66.0) * 0.035);
            float hot = smoothstep(0.52, 0.86, streak);
            hot *= hot;
            vec3 wallCol = mix(vec3(0.13, 0.014, 0.006), vec3(1.0, 0.33, 0.07) * 1.5, hot);
            wallCol = mix(wallCol, vec3(1.0, 0.74, 0.42) * 2.2, smoothstep(0.72, 1.0, hot));
            wallCol *= 0.35 + fade * 0.65;
            wallCol += vec3(1.0, 0.42, 0.12) * band * (0.2 + n2 * 0.4);
            wallCol *= wallG * 1.15;
            if (hit < sceneDist) {
                // 전선 너머에는 아무것도 없다: 불투명한 장막
                float a = clamp(wallG * 2.2, 0.0, 1.0);
                float atm = clamp(0.62 + 0.38 * smoothstep(0.85, 0.15, dir.y), 0.0, 1.0);
                color = mix(color, wallCol, a * atm);
            }
            // 가까워질수록 세상이 붉어진다
            color += vec3(0.5, 0.11, 0.035) * exp(-max(hit, 0.0) * 0.009) * wallG * 0.1;
        }
    }

    // 비 줄기: 카메라를 둘러싼 원통 여러 겹. 가늘고 빠르다. 빛을 받아 반짝인다.
    float rain = par(DataSampler, P_RAIN);
    if (rain > 0.001) {
        float az = atan(dir.x, dir.z);
        float hy = dir.y / max(length(dir.xz), 0.08);
        float sum = 0.0;
        // 화면에서 줄기 굵기가 렌즈와 상관없이 일정하도록 망원일수록 잘게, 멀리 그린다
        float zoomK = max(1.0, proj.y / 0.7);
        float radK = sqrt(zoomK);
        for (int i = 0; i < 5; i++) {
            float fi = float(i);
            float rad = (2.5 + fi * fi * 2.6) * radK;
            if (depth > 0.0 && dist < rad * length(vec2(1.0, hy))) {
                continue;
            }
            float cells = (260.0 + fi * 170.0) * zoomK;
            float col = floor(az * cells / 6.2831853);
            float seed = fract(sin(col * 12.9898 + fi * 78.233) * 43758.5453);
            float fx = fract(az * cells / 6.2831853) - 0.5;
            float speed = (6.5 + seed * 3.0) * (1.0 + fi * 0.12);
            float yy = hy * rad / (2.2 + seed * 3.0) + t * speed / (2.2 + seed * 3.0) + seed * 37.0;
            float fy = fract(yy);
            float head = smoothstep(0.0, 0.03, fy) * smoothstep(0.24 + seed * 0.2, 0.03, fy);
            float width = smoothstep(0.42, 0.05, abs(fx));
            float on = step(1.0 - rain * 0.42, fract(seed * 91.7 + floor(yy) * 0.37));
            sum += head * width * on * (0.55 / (1.0 + fi * 0.45));
        }
        vec3 rc = vec3(par(DataSampler, P_RAIN_R), par(DataSampler, P_RAIN_G), par(DataSampler, P_RAIN_B));
        vec3 ambS = vec3(par(DataSampler, P_AMB_R), par(DataSampler, P_AMB_G), par(DataSampler, P_AMB_B));
        color += rc * sum * (0.05 + dot(ambS, vec3(0.33)) * 0.34 + luma(color) * 0.12);
    }

    fragColor = vec4(encHdr(color), 1.0);
}
